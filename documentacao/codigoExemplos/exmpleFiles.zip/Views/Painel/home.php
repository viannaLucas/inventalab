<?= $this->extend('template'); ?>

<?= $this->section('content'); ?>

<?= $this->endSection('content'); ?>